# labo_54_kusbekov_nurtai
