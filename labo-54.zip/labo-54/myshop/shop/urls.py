from django.urls import path
from .views import (products_view, product_view, category_add_view, product_add_view,
                    categories_view, category_edit_view, category_delete_view)

urlpatterns = [
    path('', products_view, name='products_view'),
    path('products/', products_view, name='products_view'),
    path('products/<int:id>/', product_view, name='product_view'),
    path('categories/add/', category_add_view, name='category_add_view'),
    path('products/add/', product_add_view, name='product_add_view'),
    path('categories/', categories_view, name='categories_view'),
    path('categories/<int:id>/edit/', category_edit_view, name='category_edit_view'),
    path('categories/<int:id>/delete/', category_delete_view, name='category_delete_view'),
]
