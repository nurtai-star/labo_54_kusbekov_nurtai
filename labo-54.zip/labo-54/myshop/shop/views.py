from django.shortcuts import render, get_object_or_404, redirect
from .models import Product, Category
from .forms import CategoryForm, ProductForm

def products_view(request):
    products = Product.objects.all()
    return render(request, 'shop/products.html', {'products': products})

def product_view(request, id):
    product = get_object_or_404(Product, id=id)
    return render(request, 'shop/product.html', {'product': product})

def category_add_view(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('categories_view')
    else:
        form = CategoryForm()
    return render(request, 'shop/category_form.html', {'form': form})

def product_add_view(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            product = form.save()
            return redirect('product_view', id=product.id)
    else:
        form = ProductForm()
    return render(request, 'shop/product_form.html', {'form': form})

def categories_view(request):
    categories = Category.objects.all()
    return render(request, 'shop/categories.html', {'categories': categories})

def category_edit_view(request, id):
    category = get_object_or_404(Category, id=id)
    if request.method == 'POST':
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            form.save()
            return redirect('categories_view')
    else:
        form = CategoryForm(instance=category)
    return render(request, 'shop/category_form.html', {'form': form})

def category_delete_view(request, id):
    category = get_object_or_404(Category, id=id)
    if request.method == 'POST':
        category.delete()
        return redirect('categories_view')
    return render(request, 'shop/category_confirm_delete.html', {'category': category})
